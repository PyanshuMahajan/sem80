import BreadCrumb from "../../components/BreadCrumb.jsx";

const Profile = () => {
    return (
        <>
            <BreadCrumb pageTitle="Profile" />
        </>
    )
}
export default Profile