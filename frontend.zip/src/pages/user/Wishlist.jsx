const Wishlist = () =>{

    return(
        <>
        </>
    )
}

export default Wishlist