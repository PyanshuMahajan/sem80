import BreadCrumb from "../../components/BreadCrumb.jsx";

function Dashboard() {
    return <>
        <BreadCrumb pageTitle="Admin Dashboard"/>
        <div className="container">
            {/* <p>Dashboard Page</p> */}
        </div>
    </>;
}

export default Dashboard;
