function Footer() {
  return <h4>Footer</h4>;
}
export default Footer;
